# Private Share

## Run

Open this folder in VS Code Terminal:

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

Do NOT double-click `index.html`.

## Flow

Creator:
1. Paste original URL.
2. Generate Special Link.
3. Copy `/s/{id}` link.
4. Wait for receiver microphone permission.
5. Accept incoming voice connection.
6. Hear receiver microphone.

Receiver:
1. Opens `/s/{id}`.
2. Browser asks for microphone permission.
3. Receiver explicitly clicks Allow.
4. Original supported content stays on the receiver page.
5. Creator gets the incoming connection.
6. After creator accepts, receiver microphone is transmitted through WebRTC.

## Notes

- No location sharing.
- No Room ID.
- No Join/Create Room.
- No login.
- No dashboard.
- No hidden microphone access.
- HTTPS is required for microphone access in normal production use; localhost is allowed for local development.
- STUN is included. A TURN server is recommended for production reliability.
- Instagram/Facebook may block iframe embedding. Direct image/video URLs and YouTube embeds are supported.
- Share data is kept in memory and expires after 24 hours in this development version.
